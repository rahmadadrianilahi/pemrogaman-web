<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/chart', 'Home::chart');
$routes->get('/checkout', 'Home::checkout');

$routes->post('/submit', 'Home::submit');

$routes->get('images/(:segment)', 'Home::image/$1');

$routes->group('admin', ['filter' => ['group:admin']], function ($routes) {
    $routes->get('', 'AdminController::index');
    $routes->get('dashboard', 'AdminController::index');

    // Daftar Sepeda routes
    $routes->get('daftar-sepeda', 'AdminController::daftarSepeda');
    $routes->get('daftar-sepeda/tambah', 'AdminController::daftarSepedaTambah');
    $routes->post('daftar-sepeda/tambah', 'AdminController::createSepeda');
    $routes->get('daftar-sepeda/edit/(:num)', 'AdminController::daftarSepedaEdit/$1');
    $routes->post('daftar-sepeda/update/(:num)', 'AdminController::daftarSepedaUpdate/$1');
    $routes->get('admin/daftar-sepeda/edit/(:num)', 'Admin\DaftarSepeda::edit/$1');
    $routes->post('admin/daftar-sepeda/change', 'Admin\DaftarSepeda::change');
    $routes->post('daftar-sepeda/edit', 'AdminController::daftarSepedaEdit');
    $routes->get('daftar-sepeda/hapus', 'AdminController::daftarSepedaHapus');
    
    $routes->get('daftar-sepeda/hapus/(:num)', 'AdminController::hapusSepeda/$1');
    $routes->get('admin/daftar-sepeda/hapus/(:num)', 'AdminController::hapusSepeda/$1');
    $routes->post('admin/daftar-sepeda/hapus/(:num)', 'AdminController::hapusSepeda/$1');

    // Transaksi routes
    $routes->get('transaksi', 'AdminController::transaksi');
    $routes->get('transaksi/ubah-status', 'AdminController::transaksiUbahStatus');
    $routes->get('transaksi/hapus', 'AdminController::transaksiHapus');

    // Pelanggan routes
    $routes->get('pelanggan', 'AdminController::pelanggan');
    $routes->get('pelanggan/hapus', 'AdminController::pelangganHapus');
});

service('auth')->routes($routes);