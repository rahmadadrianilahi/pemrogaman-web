<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Toko Sepeda Adrian</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <style>
      /* Navbar */
      .navbar {
        background-color: #343a40;
      }

      .navbar-brand {
        font-size: 1.6rem;
        font-weight: bold;
        color: #ff8c00 !important;
      }

      .nav-link {
        font-weight: 500;
        color: white !important;
      }

      .nav-link:hover {
        color: #ff8c00 !important;
      }

      /* Hero Section */
      .hero-section {
        background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://source.unsplash.com/1600x900/?bicycle') no-repeat center center;
        background-size: cover;
        color: white;
        padding: 120px 0;
        text-align: center;
      }

      .hero-section h1 {
        font-size: 3rem;
        font-weight: 700;
        margin-bottom: 20px;
      }

      .hero-section p {
        font-size: 1.2rem;
        margin-bottom: 30px;
      }

      .btn-primary {
        background-color: #ff8c00;
        border-color: #ff8c00;
        padding: 12px 30px;
        font-size: 1.1rem;
      }

      .btn-primary:hover {
        background-color: #ff6a00;
        border-color: #ff6a00;
      }

      /* Main Content */
      .product-card img {
        border-radius: 10px;
        transition: transform 0.3s ease;
      }

      .product-card img:hover {
        transform: scale(1.1);
      }

      .product-card {
        border: none;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      }

      .product-card .card-body {
        text-align: center;
      }

      .product-card h5 {
        font-size: 1.4rem;
        font-weight: 600;
      }

      /* Footer */
      footer {
        background-color: #343a40;
        color: white;
        padding: 30px 0;
      }

      .social-icons a {
        color: white;
        margin: 0 15px;
        font-size: 1.5rem;
        transition: all 0.3s ease;
      }

      .social-icons a:hover {
        color: #ff8c00;
        transform: translateY(-3px);
      }
    </style>
  </head>
  <body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
      <div class="container">
        <a class="navbar-brand" href="#">
          <i class="fas fa-bicycle me-2"></i> Toko Sepeda Adrian
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link" href="#">Beranda</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Produk</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Tentang Kami</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Kontak</a>
            </li>
          </ul>
          <a href="#" class="btn btn-outline-light ms-3">
            <i class="fas fa-shopping-cart me-2"></i> Keranjang
            <span class="badge bg-danger">4</span>
          </a>
        </div>
      </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero-section">
      <div class="container">
        <h1>Selamat Datang di Toko Sepeda Adrian</h1>
        <p>Temukan sepeda terbaik dengan harga terbaik hanya di Toko Sepeda Adrian</p>
        <a href="#" class="btn btn-primary">Lihat Koleksi Sepeda</a>
      </div>
    </div>

    <!-- Main Content (Produk) -->
    <main>
      <div class="container mt-5">
        <h2 class="text-center mb-4">Koleksi Sepeda Kami</h2>
        <div class="row g-4">
          <div class="col-md-4">
            <div class="card product-card">
              <img src="https://source.unsplash.com/400x400/?bicycle1" class="card-img-top" alt="Sepeda 1">
              <div class="card-body">
                <h5>Sepeda Gunung</h5>
                <p>Harga: Rp 3.000.000</p>
                <a href="#" class="btn btn-warning">Beli Sekarang</a>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card product-card">
              <img src="https://source.unsplash.com/400x400/?bicycle2" class="card-img-top" alt="Sepeda 2">
              <div class="card-body">
                <h5>Sepeda Lipat</h5>
                <p>Harga: Rp 2.500.000</p>
                <a href="#" class="btn btn-warning">Beli Sekarang</a>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card product-card">
              <img src="https://source.unsplash.com/400x400/?bicycle3" class="card-img-top" alt="Sepeda 3">
              <div class="card-body">
                <h5>Sepeda Roadbike</h5>
                <p>Harga: Rp 4.000.000</p>
                <a href="#" class="btn btn-warning">Beli Sekarang</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>

    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-4 text-center text-md-start">
            <h5>Toko Sepeda Adrian</h5>
            <p>Toko Sepeda Terpercaya di Jambi</p>
          </div>
          <div class="col-md-4 text-center">
            <div class="social-icons">
              <a href="#"><i class="fab fa-facebook"></i></a>
              <a href="#"><i class="fab fa-instagram"></i></a>
              <a href="#"><i class="fab fa-whatsapp"></i></a>
            </div>
          </div>
          <div class="col-md-4 text-center text-md-end">
            <p>© 2024 Toko Sepeda Adrian</p>
          </div>
        </div>
      </div>
    </footer>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
