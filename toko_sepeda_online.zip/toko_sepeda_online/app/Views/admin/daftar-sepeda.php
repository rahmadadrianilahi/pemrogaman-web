<?= $this->extend('admin/template'); ?>

<?= $this->section('main'); ?>

<h2 class="mb-5">Daftar Sepeda</h2>

<div class="mb-3">
    <a href="<?= base_url('admin/daftar-sepeda/tambah') ?>" class="btn btn-primary">Tambah Sepeda</a>
</div>

<div class="mb-5">
    <table class="table table-stripped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nama Sepeda</th>
                <th scope="col">Merek</th>
                <th scope="col">Tipe</th>
                <th scope="col">Tahun Rilis</th>
                <th scope="col">Gambar</th>
                <th scope="col">Harga</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($sepedas as $sepeda): ?>
            <tr>
                <th scope="row"><?= $sepeda['id'] ?></th>
                <td><?= $sepeda['nama'] ?></td>
                <td><?= $sepeda['merek'] ?></td>
                <td><?= $sepeda['tipe'] ?></td>
                <td><?= $sepeda['tahun_rilis'] ?></td>
                <td>
                    <img src="<?= base_url($sepeda['gambar']) ?>" alt="" style="width: 150px; height: auto;">
                </td>
                <td><?= $sepeda['harga'] ?></td>
                <td>
                    <a href="<?= base_url('admin/daftar-sepeda/edit') ?>/<?= $sepeda['id'] ?>" class="btn btn-success">Edit</a>
                    <a href="<?= base_url('admin/daftar-sepeda/hapus') ?>/<?= $sepeda['id'] ?>" class="btn btn-danger">Hapus</a>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<?= $this->endSection(); ?>
