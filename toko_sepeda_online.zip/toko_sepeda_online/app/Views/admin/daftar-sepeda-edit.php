<?= $this->extend('admin/template') ?>  
<?= $this->section('main') ?>
    <div class="container">
        <h4>Edit Data Sepeda</h4>
        <form action="<?= base_url('admin/daftar-sepeda/update/' . $sepeda['id']) ?>" method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label class="form-label">Nama Sepeda</label>
                <input type="text" class="form-control" name="nama" value="<?= $sepeda['nama'] ?? '' ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Merek</label>
                <input type="text" class="form-control" name="merek" value="<?= $sepeda['merek'] ?? '' ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Tipe</label>
                <textarea class="form-control" name="tipe" rows="3"><?= $sepeda['tipe'] ?? '' ?></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Tahun Rilis</label>
                <input type="number" class="form-control" name="tahun_rilis" value="<?= $sepeda['tahun_rilis'] ?? '' ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Gambar</label>
                <input type="file" class="form-control" name="gambar">
                <?php if (!empty($sepeda['gambar'])): ?>
                    <small class="text-muted">Gambar saat ini: <?= $sepeda['gambar'] ?></small>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="form-label">Harga</label>
                <input type="number" class="form-control" name="harga" value="<?= $sepeda['harga'] ?? '' ?>">
            </div>

            <button type="submit" class="btn btn-primary">Update</button>
            <a href="<?= base_url('admin/daftar-sepeda') ?>" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
<?= $this->endSection() ?>
