<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Admin Dashboard - Toko Sepeda Online</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <style>
        :root {
            --primary-color: #4caf50;
            --secondary-color: #ff5722;
            --bg-gradient: linear-gradient(to right, #4caf50, #81c784);
            --text-dark: #2c3e50;
            --text-light: #ffffff;
            --shadow: rgba(0, 0, 0, 0.1);
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: #f4f6f9;
            color: var(--text-dark);
            margin: 0;
            padding: 0;
            min-height: 100vh;
        }

        .header {
            background: var(--bg-gradient);
            color: var(--text-light);
            padding: 20px;
            text-align: center;
            border-radius: 10px;
            box-shadow: 0 4px 15px var(--shadow);
        }

        .header h1 {
            font-size: 2rem;
            font-weight: 700;
            margin: 0;
        }

        .sidebar {
            background: var(--bg-gradient);
            color: var(--text-light);
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 4px 10px var(--shadow);
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar ul li {
            margin-bottom: 10px;
        }

        .sidebar ul li a {
            color: var(--text-light);
            text-decoration: none;
            font-size: 1rem;
            font-weight: 500;
            display: block;
            padding: 10px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .sidebar ul li a:hover {
            background: var(--secondary-color);
            box-shadow: 0 4px 15px rgba(255, 87, 34, 0.3);
            transform: translateX(10px);
        }

        .main-content {
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px var(--shadow);
        }

        .main-content h2 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 20px;
            color: var(--primary-color);
        }

        .btn-primary {
            background: var(--primary-color);
            border: none;
            padding: 10px 20px;
            color: var(--text-light);
            font-size: 1rem;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background: var(--secondary-color);
            box-shadow: 0 4px 15px rgba(255, 87, 34, 0.3);
        }

        footer {
            background: var(--bg-gradient);
            color: var(--text-light);
            text-align: center;
            padding: 10px 0;
            border-radius: 10px;
            margin-top: 20px;
            font-size: 0.9rem;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 10px var(--shadow);
            transition: all 0.3s ease;
        }

        .card:hover {
            transform: scale(1.02);
            box-shadow: 0 6px 20px var(--shadow);
        }

        @media (max-width: 768px) {
            .sidebar {
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container my-4">
        <div class="header">
            <h1><i class="fas fa-bicycle me-2"></i>Admin Dashboard</h1>
        </div>

        <div class="row mt-4">
            <div class="col-md-3">
                <div class="sidebar">
                    <ul>
                        <li><a href="<?= base_url('admin/dashboard') ?>"><i class="fas fa-home me-2"></i>Dashboard</a></li>
                        <li><a href="<?= base_url('admin/daftar-sepeda') ?>"><i class="fas fa-bicycle me-2"></i>Pilihan Sepeda</a></li>
                        <li><a href="<?= base_url('admin/transaksi') ?>"><i class="fas fa-shopping-cart me-2"></i>Transaksi</a></li>
                        <li><a href="<?= base_url('admin/pelanggan') ?>"><i class="fas fa-users me-2"></i>Pelanggan</a></li>
                        <li><a href="<?= base_url('admin/kategori') ?>"><i class="fas fa-tags me-2"></i>Kategori</a></li>
                        <li><a href="<?= base_url('admin/maintenance') ?>"><i class="fas fa-tools me-2"></i>Servis</a></li>
                    </ul>
                </div>
            </div>

            <div class="col-md-9">
                <div class="main-content">
                    <h2>Welcome to Admin Dashboard</h2>
                    <?= $this->renderSection('main'); ?>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 Toko Sepeda Adrian | Jambi</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
