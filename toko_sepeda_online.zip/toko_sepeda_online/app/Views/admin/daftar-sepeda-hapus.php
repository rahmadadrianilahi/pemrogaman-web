<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hapus Sepeda</title>
    <link rel="stylesheet" href="/path/to/your/css/styles.css">
</head>
<body>
    <div class="container">
        <h1>Konfirmasi Hapus Sepeda</h1>
        
        <?php if (isset($sepeda)): ?>
            <p>Apakah Anda yakin ingin menghapus sepeda dengan data berikut?</p>
            <ul>
                <li><strong>Nama:</strong> <?= htmlspecialchars($sepeda['nama']); ?></li>
                <li><strong>Merek:</strong> <?= htmlspecialchars($sepeda['merek']); ?></li>
                <li><strong>Tipe:</strong> <?= htmlspecialchars($sepeda['tipe']); ?></li>
                <li><strong>Tahun Rilis:</strong> <?= htmlspecialchars($sepeda['tahun_rilis']); ?></li>
                <li><strong>Gambar:</strong> <?= htmlspecialchars($sepeda['gambar']); ?></li>
                <li><strong>Harga:</strong> Rp <?= number_format($sepeda['harga'], 2, ',', '.'); ?></li>
            </ul>
            
            <form action="/admin/daftar-sepeda/hapus/<?= $sepeda['id']; ?>" method="post">
                <?= csrf_field(); ?>
                
                <button type="submit" class="btn btn-danger">Hapus</button>
                <a href="/admin/daftar-sepeda" class="btn btn-secondary">Batal</a>
            </form>
        <?php else: ?>
            <p>Data sepeda tidak ditemukan.</p>
            <a href="/admin/daftar-sepeda" class="btn btn-secondary">Kembali ke Daftar Sepeda</a>
        <?php endif; ?>
    </div>
</body>
</html>
