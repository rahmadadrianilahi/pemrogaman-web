<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\SepedaModel; 
use CodeIgniter\HTTP\ResponseInterface;

class AdminController extends BaseController 
{
    public function index() 
    {
        return view('admin/dashboard');
    }

    public function daftarSepeda() 
    {
        $sepedaModel = new SepedaModel();
        $data['sepedas'] = $sepedaModel->findAll();
        return view('admin/daftar-sepeda', $data);
    }

    public function daftarSepedaTambah() 
    {
        return view('admin/daftar-sepeda-tambah');
    }

    public function createSepeda() 
    {
        $data = $this->request->getPost();
        $file = $this->request->getFile('gambar');

        if (!$file->hasMoved()) {
            $path = $file->store('images');
            $data['gambar'] = $path;
        }

        $sepedaModel = new SepedaModel();

        if ($sepedaModel->insert($data, false)) {
            return redirect()->to('admin/daftar-sepeda')->with('berhasil', 'Data  berhasil disimpan!');
        } else {
            return redirect()->to('admin/daftar-sepeda')->with('gagal', 'Data  gagal disimpan!');
        }
    }

    public function daftarSepedaEdit($id) 
    {
        $sepedaModel = new SepedaModel();
        $data['sepeda'] = $sepedaModel->find($id);
        
        if ($data['sepeda']) {
            return view('admin/daftar-sepeda-edit', $data);
        }
        return redirect()->to('admin/daftar-sepeda')->with('gagal', 'Data sepeda tidak ditemukan.');
    }

    public function updateSepeda($id) 
    {
        $sepedaModel = new SepedaModel();
        $data = $this->request->getPost();
        
        // Handle image upload if new image is provided
        $file = $this->request->getFile('gambar');
        if ($file->isValid() && !$file->hasMoved()) {
            $path = $file->store('images');
            $data['gambar'] = $path;
        }

        if ($sepedaModel->update($id, $data)) {
            return redirect()->to('admin/daftar-sepeda')->with('berhasil', 'Data sepeda berhasil diupdate!');
        }
        return redirect()->to('admin/daftar-sepeda')->with('gagal', 'Data sepeda gagal diupdate!');
    }

    public function daftarSepedaUpdate($id) 
    {
        $sepedaModel = new SepedaModel();
        $data = $this->request->getPost();
        
        // Handle image upload if new image is provided
        $file = $this->request->getFile('gambar');
        if ($file->isValid() && !$file->hasMoved()) {
            $path = $file->store('images');
            $data['gambar'] = $path;
        }
        
        if ($sepedaModel->update($id, $data)) {
            return redirect()->to('admin/daftar-sepeda')->with('berhasil', 'Data  berhasil diupdate!');
        }
        return redirect()->to('admin/daftar-sepeda')->with('gagal', 'Data  gagal diupdate!');
    }

    public function hapusSepeda($id) 
    {
        $sepedaModel = new SepedaModel();
        $sepeda = $sepedaModel->find($id);

        if ($sepeda) {
            $sepedaModel->delete($id);
            return redirect()->to('/admin/daftar-sepeda')->with('berhasil', 'Data sepeda berhasil dihapus.');
        }
        return redirect()->to('/admin/daftar-sepeda')->with('gagal', 'Data sepeda tidak ditemukan.');
    }

    public function transaksi() 
    {
        return view('admin/transaksi');
    }

    public function transaksiUbahStatus() 
    {
        return view('admin/transaksi-ubah-status');
    }

    public function transaksiHapus() 
    {
        return view('admin/transaksi-hapus');
    }

    public function pelanggan() 
    {
        return view('admin/pelanggan');
    }

    public function pelangganHapus() 
    {
        return view('admin/pelanggan-hapus');
    }
}